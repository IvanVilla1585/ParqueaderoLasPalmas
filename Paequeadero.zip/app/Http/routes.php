<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', [
  'uses' => 'HomeController@homeView',
  'as' => 'show_home_path',
]);

Route::get('/Reservas', [
  'uses' => 'HomeController@reservaView',
  'as' => 'show_reserva_path',
]);

Route::get('/Contacto', [
  'uses' => 'HomeController@contactoView',
  'as' => 'show_contacto_path',
]);

Route::get('/Blog', [
  'uses' => 'HomeController@blogView',
  'as' => 'show_blog_path',
]);
