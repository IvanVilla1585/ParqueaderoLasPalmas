<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Parqueadero</title>
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/materialize.css')); ?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body>
  <header class="header">
    <div class="navbar-fixed">
      <nav class="navbar-fixed">
        <div class="nav-wrapper">
          <a href="#" class="brand-logo">
            <div class="logo">
              <figure>
                <img src="/images/logo.jpg" alt="">
              </figure>
            </div>
          </a>
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li>
              <a href="<?php echo e(route('show_home_path')); ?>" class="icon-home3">Home</a>
            </li>
            <li>
              <a href="<?php echo e(route('show_reserva_path')); ?>">Reservas</a>
            </li>
            <li>
              <a href="{% url 'navegacion:nosotros' %}">Nosotros</a>
            </li>
            <li>
              <a href="<?php echo e(route('show_contacto_path')); ?>">Contacto</a>
            </li>
            <li>
              <a href="<?php echo e(route('show_blog_path')); ?>">Blog</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>
  <?php echo $__env->yieldContent('content'); ?>
  <footer class="footer">
    <div class="contacto">
      <p>Título</p>
      <p class="text_footer">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet officiis dignissimos ducimus
      </p>
      <form action="" class="form_contact">
        <div class="inputs_footer row">
          <div class="input-field col s12">
            <span class="icon-user">
              <input type="text" class="validate" name="name_contact" id="name_contact" >
              <label for="name_contact">Nombre Completo</label>
            </span>
          </div>
          <div class="input-field col s12">
            <span class="icon-mail-envelope-closed">
              <input type="email" name="email_contact" id="email_contact" >
              <label for="email_contact">Correo Electrónico</label>
            </span>
          </div>
        </div>
        <input type="submit" class="boton1" value="Enviar">
      </form>
    </div>
    <div class="company">
      <p>Empresa</p>
      <ul>
        <li>
          <span class="iconss chevron-right">
            <a  href="">Nosotros</a>
          </span>
        </li>
        <li>
          <span class="iconss chevron-right">
            <a href="">Bolg</a>
          </span>
        </li>
      </ul>
    </div>
    <div class="help">
      <p>Ayuda</p>
      <ul>
        <li>
          <span class="iconss chevron-right">
            <a href=""  href="">Mapa del sitio</a>
          </span>
        </li>
      </ul>
    </div>
    <div class="redes_footer">
      <div>
        <p>Contáctanos</p>
        <ul>
          <li>
            <span class="iconss chevron-right">
              <a  href="">Contacto</a>
            </span>
          </li>
          <li>
            <span class="iconss chevron-right">
              <a href="">Reserva</a>
            </span>
          </li>
        </ul>
        <p>Visitanos en nuestras redes</p>
        <aside class="redes">
          <a href="https://www.facebook.com/Parqueadero-las-palmas-J-M-345236772297223" target="_blanck" class="facebook icon-facebook"></a>
          <a href="" target="_blanck" class="istagram icon-youtube"></a>
          <a href="" target="_blanck" class="youtube icon-instagram"></a>
        </aside>
      </div>
    </div>
  </footer>
  <div id="modal-alert" class="modal modal-alert">
    <div class="modal-content">
      <div class="logo">
        <figure>
          <img src="/images/logo.jpg" alt="">
        </figure>
      </div>
      <div class="title_modal">
        <h2 class="color_verde">Alerta!</h2>
      </div>
      <p id="text-modal"></p>
    </div>
    <div class="modal-footer">
      <a href="#!" class=" modal-action modal-close waves-effect waves-green waves-light btn">Aceeptar</a>
    </div>
  </div>
<script src="<?php echo e(URL::asset('js/sdk.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/app.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/materialize.js')); ?>" type="text/javascript"></script>
<script>

$(document).ready(function(){
  $('.parallax').parallax();
  $('.carousel').carousel();
  $('.slider').slider({
      full_width: true,
      time_constant: 2000
    });
    $('.datepicker').pickadate({
      selectMonths: true, // Creates a dropdown to control month
      selectYears: 15 // Creates a dropdown of 15 years to control year
    });
});

</script>
</body>
</html>
