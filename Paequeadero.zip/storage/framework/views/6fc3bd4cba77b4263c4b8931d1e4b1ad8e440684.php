<?php $__env->startSection('content'); ?>
<section class="container_contacto">
  <article class="contacto_form">
    <div class="parallax-container">
      <div class="parallax"><img src="/images/banner1.jpg"></div>
    </div>
    <div class="section gren">
      <div class="row container">
        <h2 class="header">Contacto</h2>
        <div class="container_form">
          <div class="contacto row">
            <form action="{% url 'contacto:email' %}" method="pos" class="form_contacto  col s12">
              <div class="inputs" id="inputs">
                <div class="input-field col s8">
                  <span class="icon-user nombre">
                    <input type="text" class="validate" name="name" id="name" >
                    <label for="name">Nombre Completo</label>
                  </span>
                </div>
                <div class="input-field col s8">
                  <span class="icon-mail-envelope-closed email">
                    <input type="text" class="validate" name="email" id="email" >
                    <label for="email">Correo Electronico</label>
                  </span>
                </div>
                <div class="input-field col s8">
                  <textarea id="textarea1" class="materialize-textarea"></textarea>
                  <label for="textarea1">Mensaje</label>
                </div>
                <div class="buttons col s11" id="boton_enviar">
                  <input type="submit" name="enviar" id="enviar" class="waves-effect waves-light btn-large boton1" value="Enviar">
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="parallax-container">
      <div class="parallax"><img src="/images/banner2.jpg"></div>
    </div>
  </article>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>