@extends('layouts/base')

@section('content')
<section class="container_banner">
  <article class="banner">
    <div class="slider" id="slider">
      <ul class="slides" id="slides">
        <li>
          <img src="/images/banner1.jpg"> <!-- random image -->
        </li>
        <li>
          <img src="/images/banner2.jpg"> <!-- random image -->
        </li>
        <li>
          <img src="/images/banner3.jpg"> <!-- random image -->
        </li>
        <li>
          <img src="/images/banner4.jpg"> <!-- random image -->
        </li>
      </ul>
    </div>
  </article>
</section>
<section class="container_info">
  <article class="reservation">
    <p class="title color">Reserva ya con Nosotros</p>
    <div class="reservation_text">
      <div>
        <figure>
          <img src="/images/reserva.jpg" alt="">
        </figure>
        <p class="text_reservation color">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, obcaecati dolores! Molestiae et quidem dolorum saepe minima ipsam magnam. Veniam laborum repellendus odit ipsum aut, quos dolore nihil ipsa deserunt?
        </p>
      </div>
    </div>
    <div class="registre_container">
      <div class="pasos">
        <canvas class="canvas" id="canvas1" width="600" height="150"></canvas>
      </div>
      <div class="registre row">
        <form action="" class="form_registre col s12">
          <div class="inputs row" id="inputs">
            <div class="input-field col s6">
              <span class="icons calendar2 fechai">
                <input type="date" class="datepicker" name="fechai" id="fechai" >
                <label for="fechai">Fecha de Ingreso</label>
              </span>
            </div>
            <div class="input-field col s6">
              <span class="icons clock3 horai">
                <input type="text" name="horai" id="horai" >
                <label for="horai">Hora de Ingreso</label>
              </span>
            </div>
          </div>
          <div class="inputs row" id="inputs">
            <div class="input-field col s6">
              <span class="icons calendar2 fechasa">
                <input type="date" class="datepicker" name="fechasa" id="fechasa" >
                <label for="fechai">Fecha de Salida</label>
              </span>
            </div>
            <div class="input-field col s6">
              <span class="icons clock3 horasa">
                <input type="text" name="horasa" id="horasa" >
                <label for="horasa">Hora de Salida</label>
              </span>
            </div>
          </div>
          <div class="buttons col s11">
            <input type="button" name="siguiente" id="siguiente" class="waves-effect waves-light btn-large boton1" value="Siguiente">
          </div>
          <div class="inputs_info row" id="inputs_info">
            <div class="input-field col s6">
              <span class="icon-user nombre">
                <input type="text" class="validate" name="name" id="name" >
                <label for="name">Nombre Completo</label>
              </span>
            </div>
            <div class="input-field col s6">
              <span class="icons mobile cell">
                <input type="text" name="cell" id="cell" >
                <label for="cell">Número de Celular</label>
              </span>
            </div>
          </div>
          <div class="inputs_info row" id="inputs_info1">
            <div class="input-field col s6">
              <span class="icon-mail-envelope-closed email">
                <input type="text" class="validate" name="email" id="email" >
                <label for="email">Correo Electronico</label>
              </span>
            </div>
            <div class="input-field col s6">
              <span class="icons car carr">
                <input type="text" name="car" id="car" >
                <label for="car">Placa del Vehiculo</label>
              </span>
            </div>
          </div>
          <div class="buttons col s11">
            <input type="button" name="siguiente" id="siguiente" class="waves-effect waves-light btn-large boton1" value="Reservar">
          </div>
        </div>
      </form>
    </div>
  </article>
  <article class="images">
    <p class="title">¡Nuestras Instalaciones!</p>
    <div class="carousel">
      <a class="carousel-item" href="#one!"><img src="/images/parqueadero6.jpg"></a>
      <a class="carousel-item" href="#two!"><img src="/images/parqueadero7.jpg"></a>
      <a class="carousel-item" href="#three!"><img src="/images/parqueadero1.jpg"></a>
      <a class="carousel-item" href="#four!"><img src="/images/parqueadero2.jpg"></a>
    </div>
  </article>
  <article class="time">
    <div class="data_fly">
      <p class="sub_tittle">Informate aqui! del estado de tu vuelo</p>
      <figure>
        <img src="/images/reserva.jpg" alt="">
      </figure>
      <div class="consult_fly">
        <a href="/consultarvuelo.html" class="icons aircraft boton1">Consultar</a>
      </div>
    </div>
    <div class="data_time">
      <p class="sub_tittle">Informate del estado del tiempo en nuestras instalaciones</p>
      <div class="time_info">
        <div class="data_time_info">
          <div class="info_text_time">
            <span id="nombre"></span>
            <figure>
              <img id="icon" src="" alt="">
            </figure>
            <spa id="temp"></spa>
            <span id="descripcion"></span>
          </div>
          <div class="info_price_dolar">
            <p id="dolar" class="dolar sub_tittle">Precio del Dolar</p>
            <span id="price" class="price"></span>
          </div>

        </div>
      </div>
    </div>
    <div class="data_facebook">
      <p id="dolar" class="sub_tittle">Siguenos y continua disfrutando de nuestras beneficios</p>
      <div class="info_facebook" id="info_facebook">
      </div>
    </div>
  </article>
  <article class="location">
    <p class="title">¿Que esperas para visitarnos?</p>
    <div id="map" class="map">

    </div>
  </article>
</section>
@stop
