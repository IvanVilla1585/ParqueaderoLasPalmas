@extends('layouts/base')

@section('content')
<section class="container_blog">
<article class="info_blog">
  <div class="images_blog">
    <figure>
      <img src="/images/viaje1.jpg" alt="">
    </figure>
  </div>
  <div class="text_blog">
    <div class="card-panel greenblog">
      <span class="white-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus dolore labore,
        saepe fuga voluptates cupiditate dicta porro! Harum magni placeat impedit quam reiciendis,
        fuga quasi rem, voluptas veniam ullam. Reprehenderit.
      </span>
    </div>
  </div>
</article>
<article class="info_blog">
  <div class="text_blog">
    <div class="card-panel greenblog">
      <span class="white-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus dolore labore,
        saepe fuga voluptates cupiditate dicta porro! Harum magni placeat impedit quam reiciendis,
        fuga quasi rem, voluptas veniam ullam. Reprehenderit.
      </span>
    </div>
  </div>
  <div class="images_blog">
    <figure>
      <img src="/images/viaje1.jpg" alt="">
    </figure>
  </div>
</article>
<article class="info_blog">
  <div class="images_blog">
    <figure>
      <img src="/images/viaje1.jpg" alt="">
    </figure>
  </div>
  <div class="text_blog">
    <div class="card-panel greenblog">
      <span class="white-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus dolore labore,
        saepe fuga voluptates cupiditate dicta porro! Harum magni placeat impedit quam reiciendis,
        fuga quasi rem, voluptas veniam ullam. Reprehenderit.
      </span>
    </div>
  </div>
</article>
<article class="info_blog">
  <div class="text_blog">
    <div class="card-panel greenblog">
      <span class="white-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus dolore labore,
        saepe fuga voluptates cupiditate dicta porro! Harum magni placeat impedit quam reiciendis,
        fuga quasi rem, voluptas veniam ullam. Reprehenderit.
      </span>
    </div>
  </div>
  <div class="images_blog">
    <figure>
      <img src="/images/viaje1.jpg" alt="">
    </figure>
  </div>
</article>
</section>
@stop
