@extends('layouts/base')

@section('content')
<section class="container_register">
  <article class="reservation_form">
    <div class="parallax-container">
      <div class="parallax"><img src="/images/banner1.jpg"></div>
    </div>
    <div class="section gren">
      <div class="row container">
        <h2 class="header">Reservas</h2>
        <div class="pasos">
          <canvas class="canvas" id="canvas1" width="600" height="150"></canvas>
        </div>
        <div class="registre row">
          <form action="" class="form_registre col s12">
            <div class="inputs row" id="inputs">
              <div class="input-field col s6">
                <span class="icons calendar2 fechai">
                  <input type="date" class="datepicker" name="fechai" id="fechai" >
                  <label for="fechai">Fecha de Ingreso</label>
                </span>
              </div>
              <div class="input-field col s6">
                <span class="icons clock3 horai">
                  <input type="text" name="horai" id="horai" >
                  <label for="horai">Hora de Ingreso</label>
                </span>
              </div>
            </div>
            <div class="inputs row" id="inputs1">
              <div class="input-field col s6">
                <span class="icons calendar2 fechasa">
                  <input type="date" class="datepicker" name="fechasa" id="fechasa" >
                  <label for="fechai">Fecha de Salida</label>
                </span>
              </div>
              <div class="input-field col s6">
                <span class="icons clock3 horasa">
                  <input type="text" name="horasa" id="horasa" >
                  <label for="horasa">Hora de Salida</label>
                </span>
              </div>
            </div>
            <div class="buttons col s11">
              <input type="button" name="siguiente" id="siguiente" class="waves-effect waves-light btn-large boton1" value="Siguiente">
            </div>
            <div class="inputs_info row" id="inputs_info">
              <div class="input-field col s6">
                <span class="icon-user nombre">
                  <input type="text" class="validate" name="name" id="name" >
                  <label for="name">Nombre Completo</label>
                </span>
              </div>
              <div class="input-field col s6">
                <span class="icons mobile cell">
                  <input type="text" name="cell" id="cell" >
                  <label for="cell">Número de Celular</label>
                </span>
              </div>
            </div>
            <div class="inputs_info row" id="inputs_info1">
              <div class="input-field col s6">
                <span class="icon-mail-envelope-closed email">
                  <input type="text" class="validate" name="email" id="email" >
                  <label for="email">Correo Electronico</label>
                </span>
              </div>
              <div class="input-field col s6">
                <span class="icons car carr">
                  <input type="text" name="car" id="car" >
                  <label for="car">Placa del Vehiculo</label>
                </span>
              </div>
            </div>
            <div class="buttons col s11" id="boton_reserva">
              <input type="button" name="reserva" id="reserva" class="waves-effect waves-light btn-large boton1" value="Reservar">
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="parallax-container">
      <div class="parallax"><img src="/images/banner2.jpg"></div>
    </div>

  </article>
</section>
@stop
