@extends('layouts/base')

@section('content')
<section class="row consulta">
  <article class="row">
    <iframe src="http://www.aeropuertorionegro.co/web/page/288/Salidas-y-llegadas"  name="ventana"></iframe>
  </article>
</section>
@stop
