@extends('layouts/base')

@section('content')
<section class="container_blog">
  <article class="info_blog row">
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </article>
  <article class="info_blog row">
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </article>
  <article class="info_blog row">
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </article>
  <article class="info_blog row">
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="images_blog col s12 m6">
      <div class="row">
        <div class="col s12 m10 offset-m1">
          <div class="card medium">
            <div class="card-image">
              <img src="/images/viaje1.jpg">
            </div>
            <div class="card-content">
              <p>Soy una tarjeta muy simple. Soy buena mostrando pequeños trozos de información. Soy conveniente porque requiero pocas etiquetas para usarme efectivamente.</p>
            </div>
            <div class="card-action">
              <a href="#">Este es un enlace</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </article>
</section>
@stop
