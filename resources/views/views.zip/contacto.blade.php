@extends('layouts/base')

@section('content')
<section class="container_contacto">
  <div class="row">
    <article class="contacto_form">
      <div class="section gren">
        <div class="row container">
          <h3 class="header">Contacto</h3>
          <div class="col s12 container_form">
            <div class="contacto row">
              <form action="{{ route('send_email_path') }}" method="post" class="form_contacto row">
                <input type="hidden" name="_token" value="{{ csrf_token() }}"/>
                <div class="inputs row" id="inputs">
                  <div class="input-field col s12 m8 offset-m2">
                    <span class="icon-user nombre">
                      <input type="text" class="validate" name="name" id="name" >
                      <label for="name">Nombre Completo</label>
                    </span>
                  </div>
                  <div class="input-field col s12 m8 offset-m2">
                    <span class="icon-mail-envelope-closed email">
                      <input type="text" class="validate" name="email" id="email" >
                      <label for="email">Correo Electronico</label>
                    </span>
                  </div>
                  <div class="input-field col s12 m8 offset-m2">
                    <textarea id="textarea1" class="materialize-textarea"></textarea>
                    <label for="textarea1">Mensaje</label>
                  </div>
                  <div class="buttons col s11" id="boton_enviar">
                    <input type="submit" name="enviar" id="enviar" class="waves-effect waves-light btn" value="Enviar">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </article>
  </div>
</section>
@stop
